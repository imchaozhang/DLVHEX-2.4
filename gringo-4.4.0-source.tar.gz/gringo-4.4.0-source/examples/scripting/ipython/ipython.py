#script (python)
from IPython import embed

def main(prg):
    embed()

#end.
